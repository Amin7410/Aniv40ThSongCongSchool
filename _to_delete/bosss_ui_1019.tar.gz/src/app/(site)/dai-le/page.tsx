import type { Metadata } from 'next'
import Link from 'next/link'
import { getEvent, payload } from '@/lib/data'
import { embedURL, liveState } from '@/lib/live'
import { dstr, fundSummary, guestbook } from '@/lib/home'
import { zoneItems } from '@/lib/view'
import { getZones } from '@/lib/data'
import { SubmitForm } from '@/components/SubmitForm'
import { CountdownBand } from '@/components/proto/Countdown'
import { CampaignCard } from '@/components/proto/Campaign'
import { CandleCard, FundCard, LiveBlock, QuizCard } from '@/components/proto/Event'

export const dynamic = 'force-dynamic'
export const metadata: Metadata = { title: 'Đại lễ 40 năm (1986 – 2026)' }

export default async function EventPage() {
  const [ev, fund, gb, zones, qr] = await Promise.all([
    getEvent(),
    fundSummary(),
    guestbook(30),
    getZones(),
    (await payload()).find({ collection: 'quiz-questions', limit: 50, sort: 'order', depth: 0 }),
  ])
  const st = liveState(ev)
  const closed = ev.submissionsOpen === false
  const memZ = zones.find((z) => z.type === 'memories')
  const mem = memZ ? await zoneItems(memZ) : []
  const people = new Set(mem.map((m) => m.by).filter(Boolean)).size
  const gens = new Set(mem.map((m) => Math.min(3, Math.max(0, Math.floor((+(/\d{4}/.exec(m.khoa)?.[0] || m.year || 0) - 1986) / 10))))).size
  const qs = qr.docs.map((q) => ({ q: q.question, a: q.options || [], c: q.correctIndex, e: q.explanation || '' }))

  return (
    <>
      <section className="zone-hero">
        <div className="zone-hero-in">
          <Link className="back" href="/">‹ Về gian trung tâm</Link>
          <h1>Đại lễ 40 năm (1986 – 2026)</h1>
          <p>Cùng hướng về {String(ev.title || 'lễ kỷ niệm').toLowerCase()}: gửi lời chúc, thắp nến tri ân, gửi kỷ vật và chung tay xây dựng {fund.name}.</p>
        </div>
      </section>
      {st !== 'live' && <CountdownBand title={ev.title || 'Lễ kỷ niệm 40 năm thành lập trường'} startsAt={ev.startsAt} place={ev.place} liveUrl={ev.liveUrl as string} after={st === 'after'} />}
      <div className="section">
        <div className="ev-grid">
          <div className="card wide">
            <h2>Xem trực tiếp</h2>
            <p className="lead">Cựu học sinh ở xa cùng hướng về trường: xem buổi lễ, thả cảm xúc, và quay lại tham quan phòng truyền thống bất cứ lúc nào.</p>
            <LiveBlock ev={{ startsAt: ev.startsAt, liveMode: ev.liveMode, liveHours: ev.liveHours }} initial={st} embed={embedURL(ev.liveUrl as string)} liveUrl={ev.liveUrl as string} staticMode={!!ev.staticFallback} />
          </div>
          <div className="card" id="so-luu-niem">
            <h2>Sổ lưu niệm</h2>
            <p className="lead">Lời chúc được Ban quản trị duyệt trước khi hiển thị.</p>
            <SubmitForm
              kind="guestbook"
              closed={closed}
              submitLabel="Gửi lời chúc"
              successText="Đã gửi lời chúc. Lời chúc sẽ hiển thị sau khi được duyệt."
              fields={[
                { name: 'name', label: 'Họ và tên', required: true, max: 80, placeholder: 'VD: Nguyễn Văn A', half: true },
                { name: 'cohort', label: 'Khóa học, đơn vị', max: 60, placeholder: 'VD: Khóa 2005 – 2008', half: true },
                { name: 'message', label: 'Lời chúc', type: 'textarea', required: true, max: 600, placeholder: 'Viết lời chúc gửi nhà trường…' },
              ]}
            />
            {gb.length ? (
              <div className="gb-list">
                {gb.map((g) => (
                  <div key={g.id} className="gb"><p>{g.msg}</p><small>{g.name}{g.khoa ? ', ' + g.khoa : ''}, {dstr(g.at)}</small></div>
                ))}
              </div>
            ) : (
              <p className="note" style={{ marginTop: 14 }}>Chưa có lời chúc nào được đăng.</p>
            )}
          </div>
          <div className="card center">
            <h2>Thắp nến tri ân</h2>
            <p className="lead">Mỗi người thắp một ngọn nến tri ân các thế hệ thầy cô đã cống hiến cho nhà trường.</p>
            <CandleCard staticMode={!!ev.staticFallback} />
          </div>
          <div className="card">
            <h2>{fund.name}</h2>
            <p className="lead">Quét mã QR để chuyển khoản, sau đó báo đóng góp để Ban quản trị xác nhận.</p>
            <FundCard initial={fund} />
            <details style={{ marginTop: 12 }}>
              <summary style={{ cursor: 'pointer', fontWeight: 600 }}>Báo đóng góp của tôi</summary>
              <div style={{ marginTop: 12 }}>
                <SubmitForm
                  kind="donation"
                  closed={closed}
                  submitLabel="Gửi thông tin đóng góp"
                  successText="Đã gửi thông tin đóng góp. Ban quản trị sẽ xác nhận sau khi đối chiếu."
                  fields={[
                    { name: 'name', label: 'Tên hiển thị', max: 80, placeholder: 'VD: Lớp 12A1 khóa 2010 – 2013, hoặc Ẩn danh', half: true },
                    { name: 'amount', label: 'Số tiền (đồng)', type: 'number', required: true, placeholder: 'VD: 500000', half: true },
                    { name: 'cohort', label: 'Khóa, lớp', max: 60, half: true },
                    { name: 'contact', label: 'SĐT/Email để xác nhận (không công khai)', max: 120, half: true },
                    { name: 'message', label: 'Ghi chú cho Ban quản trị', max: 200, placeholder: 'VD: Chuyển khoản lúc 9:00 ngày 10/11', hint: 'Ban quản trị đối chiếu sao kê rồi mới xác nhận.' },
                    { name: 'anonymous', label: 'Không công khai tên tôi', type: 'checkbox' },
                  ]}
                />
              </div>
            </details>
          </div>
          <div style={{ gridColumn: '1/-1' }}>
            <CampaignCard compact start={ev.campaignStart as string} end={ev.campaignEnd as string} items={mem.length} people={people} gens={gens} closed={closed} />
          </div>
          <div className="card">
            <h2>Minigame lịch sử trường</h2>
            <p className="lead">Trắc nghiệm vui {qs.length} câu về chặng đường 40 năm.</p>
            <QuizCard qs={qs} />
          </div>
        </div>
      </div>
    </>
  )
}
