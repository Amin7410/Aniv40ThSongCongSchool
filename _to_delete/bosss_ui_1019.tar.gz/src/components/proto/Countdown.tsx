'use client'
import Link from 'next/link'
import { useEffect, useState } from 'react'
import { I } from '@/lib/proto-svg'
import { Raw } from '../Raw'

/** Dải đếm ngược Đại lễ (giống prototype). */
export function CountdownBand({ title, startsAt, place, liveUrl, after }: { title: string; startsAt?: string | null; place?: string | null; liveUrl?: string | null; after?: boolean }) {
  const [now, setNow] = useState<number | null>(null)
  useEffect(() => {
    const first = setTimeout(() => setNow(Date.now()), 0)
    const t = setInterval(() => setNow(Date.now()), 1000)
    return () => {
      clearTimeout(first)
      clearInterval(t)
    }
  }, [])
  const end = startsAt ? Date.parse(startsAt) : NaN
  const when = Number.isNaN(end)
    ? ''
    : new Date(end).toLocaleString('vi-VN', { hour: '2-digit', minute: '2-digit', day: '2-digit', month: '2-digit', year: 'numeric', timeZone: 'Asia/Ho_Chi_Minh' })
  let ms = Number.isNaN(end) || now === null ? 0 : end - now
  const units = ([[864e5, 'ngày'], [36e5, 'giờ'], [6e4, 'phút'], [1e3, 'giây']] as const).map(([k, l]) => {
    const v = Math.floor(ms / k)
    ms -= v * k
    return [v, l] as const
  })
  return (
    <section className="cd-band">
      <div className="cd-in">
        <div>
          <h2>{title}</h2>
          <p>{when}{place ? `, ${place}` : ''}</p>
        </div>
        <div className="cd" aria-label="Đếm ngược">
          {!Number.isNaN(end) && now !== null && end - now <= 0 ? (
            <div style={{ minWidth: 'auto', padding: '10px 16px' }}><b style={{ fontSize: 24 }}>{after ? 'Đại lễ đã diễn ra' : 'Đại lễ đang diễn ra'}</b></div>
          ) : (
            units.map(([v, l]) => (
              <div key={l}><b>{now === null ? '--' : String(v).padStart(2, '0')}</b><span>{l}</span></div>
            ))
          )}
        </div>
        <div className="cd-acts">
          <Link className="btn gold" href="/dai-le">Gửi lời chúc</Link>
          {liveUrl && (
            <a className="btn ghost" style={{ color: '#f6e7c8', borderColor: 'rgba(241,212,139,.5)' }} href={liveUrl} target="_blank" rel="noopener noreferrer">
              <Raw html={I.live} /> {after ? 'Xem lại buổi lễ' : 'Xem trực tiếp'}
            </a>
          )}
        </div>
      </div>
    </section>
  )
}
