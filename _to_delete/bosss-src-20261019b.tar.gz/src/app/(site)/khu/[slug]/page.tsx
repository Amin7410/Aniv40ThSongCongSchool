import type { Metadata } from 'next'
import Link from 'next/link'
import { notFound } from 'next/navigation'
import { getExhibits, getZone } from '@/lib/data'
import { ExhibitCard } from '@/components/Cards'
import { GENERATIONS } from '@/lib/text'
import { BeforeAfter, type Pair } from '@/components/BeforeAfter'
import { firstMedia, imgUrl } from '@/lib/data'

export const dynamic = 'force-dynamic'

type P = { params: Promise<{ slug: string }>; searchParams: Promise<{ q?: string; loc?: string; the_he?: string; trang?: string }> }

export async function generateMetadata({ params }: P): Promise<Metadata> {
  const z = await getZone((await params).slug)
  return z ? { title: z.title, description: z.description || undefined } : {}
}

export default async function ZonePage({ params, searchParams }: P) {
  const { slug } = await params
  const sp = await searchParams
  const z = await getZone(slug)
  if (!z) notFound()
  const q = (sp.q || '').slice(0, 80)
  const cat = (sp.loc || '').slice(0, 80)
  const gen = z.type === 'memories' ? sp.the_he || '' : ''
  const page = Math.max(1, Number(sp.trang) || 1)
  const res = await getExhibits(z.id, { q, category: cat || undefined, generation: gen || undefined, page })

  // Khu Cơ sở vật chất: ghép cặp ảnh cùng "mã cặp" thành thanh trượt Ngày ấy – Bây giờ (năm nhỏ = ngày ấy)
  const pairs: Pair[] = []
  if (z.type === 'campus') {
    const all = (await getExhibits(z.id, { limit: 500 })).docs
    const groups = new Map<string, typeof all>()
    for (const e of all) if (e.pairKey && firstMedia(e)) groups.set(e.pairKey, [...(groups.get(e.pairKey) || []), e])
    for (const [key, g] of groups) {
      if (g.length < 2) continue
      const s = [...g].sort((a, b) => (a.year || 0) - (b.year || 0))
      const b0 = s[0], a0 = s[s.length - 1]
      pairs.push({
        key,
        before: { src: imgUrl(firstMedia(b0), 'full')!, title: b0.title, year: b0.year, old: !!firstMedia(b0)?.isHistorical },
        after: { src: imgUrl(firstMedia(a0), 'full')!, title: a0.title, year: a0.year },
      })
    }
  }

  const href = (patch: Record<string, string>) => {
    const u = new URLSearchParams({ ...(q && { q }), ...(cat && { loc: cat }), ...(gen && { the_he: gen }), ...patch })
    for (const [k, v] of [...u.entries()]) if (!v) u.delete(k)
    const s = u.toString()
    return `/khu/${z.slug}${s ? '?' + s : ''}`
  }

  return (
    <>
      <section className="zone-hero">
        <div className="wrap">
          <Link className="back" href="/">‹ Về gian trung tâm</Link>
          <h1>{z.title}</h1>
          {z.description && <p>{z.description}</p>}
        </div>
      </section>
      <div className="wrap section">
        <form className="filters" role="search" action={`/khu/${z.slug}`}>
          <label className="sr" htmlFor="q">Tìm trong khu</label>
          <input id="q" type="search" name="q" defaultValue={q} placeholder="Tìm theo tên, có thể gõ không dấu…" />
          {cat && <input type="hidden" name="loc" value={cat} />}
          {gen && <input type="hidden" name="the_he" value={gen} />}
          <button className="btn" type="submit">Tìm</button>
        </form>
        {(z.categories?.length || 0) > 0 && (
          <div className="filters" aria-label="Lọc theo phân loại">
            <Link className="chip" aria-current={!cat} href={href({ loc: '', trang: '' })}>Tất cả</Link>
            {z.categories!.map((c) => (
              <Link key={c} className="chip" aria-current={cat === c} href={href({ loc: c, trang: '' })}>{c}</Link>
            ))}
          </div>
        )}
        {z.type === 'memories' && (
          <div className="filters" aria-label="Lọc theo thế hệ">
            <Link className="chip" aria-current={!gen} href={href({ the_he: '', trang: '' })}>Mọi thế hệ</Link>
            {GENERATIONS.map((g) => (
              <Link key={g.key} className="chip" aria-current={gen === g.key} href={href({ the_he: g.key, trang: '' })}>{g.label}</Link>
            ))}
            <Link className="btn ghost" href="/gui-ky-vat">+ Gửi kỷ vật</Link>
          </div>
        )}
        {pairs.length > 0 && !q && <BeforeAfter pairs={pairs} />}
        <p className="meta" aria-live="polite">{res.total} mục{q ? ` khớp “${q}”` : ''}</p>
        {res.docs.length ? (
          <div className="grid">{res.docs.map((e) => <ExhibitCard key={e.id} e={e} z={z} />)}</div>
        ) : (
          <p className="notice">{q || cat || gen ? 'Không có mục phù hợp.' : 'Khu này đang được nhà trường cập nhật tư liệu.'}</p>
        )}
        {res.pages > 1 && (
          <nav className="pager" aria-label="Phân trang">
            {page > 1 && <Link className="chip" href={href({ trang: String(page - 1) })}>‹ Trước</Link>}
            <span className="meta">Trang {page}/{res.pages}</span>
            {page < res.pages && <Link className="chip" href={href({ trang: String(page + 1) })}>Sau ›</Link>}
          </nav>
        )}
      </div>
    </>
  )
}
