import type { Metadata } from 'next'
import Link from 'next/link'
import { notFound } from 'next/navigation'
import { getApproved, getEvent, getExhibit, getExhibits, getZone, imgUrl, type MediaDoc, type ZoneDoc } from '@/lib/data'
import { subtitleOf } from '@/components/Cards'
import { SubmitForm } from '@/components/SubmitForm'

export const dynamic = 'force-dynamic'

type P = { params: Promise<{ slug: string; id: string }> }

async function load(p: P) {
  const { slug, id } = await p.params
  const z = await getZone(slug)
  const n = Number(id)
  if (!z || !Number.isInteger(n)) return null
  const e = await getExhibit(n)
  if (!e) return null
  const zid = typeof e.zone === 'object' ? e.zone.id : e.zone
  if (zid !== z.id) return null
  return { z, e }
}

export async function generateMetadata(p: P): Promise<Metadata> {
  const r = await load(p)
  if (!r) return {}
  const m = (r.e.media || []).find((x) => typeof x === 'object') as MediaDoc | undefined
  const img = imgUrl(m, 'card')
  return { title: r.e.title, description: r.e.description?.slice(0, 160) || r.z.title, openGraph: img ? { images: [img] } : undefined }
}

const TRIBUTE_TYPES = new Set(['leaders', 'staff'])

export default async function ExhibitPage(p: P) {
  const r = await load(p)
  if (!r) notFound()
  const { z, e } = r
  const media = (e.media || []).filter((m): m is MediaDoc => typeof m === 'object')
  const [siblings, tributes, ev] = await Promise.all([
    getExhibits(z.id, { limit: 500 }),
    TRIBUTE_TYPES.has(z.type) ? getApproved('tribute', 50, 1, [{ tributeTo: { equals: e.id } }]) : null,
    getEvent(),
  ])
  const i = siblings.docs.findIndex((x) => x.id === e.id)
  const prev = i > 0 ? siblings.docs[i - 1] : null
  const next = i >= 0 && i < siblings.docs.length - 1 ? siblings.docs[i + 1] : null

  return (
    <div className="wrap section">
      <p><Link href={`/khu/${z.slug}`}>‹ {z.title}</Link></p>
      <article className="detail">
        <div className="gallery">
          {media.length ? (
            media.map((m) =>
              m.url && /\.mp4$/i.test(m.url) ? (
                <video key={m.id} src={m.url} controls preload="metadata" />
              ) : (
                <img key={m.id} src={imgUrl(m, 'full') || ''} alt={m.alt || e.title} className={m.isHistorical ? 'old' : undefined} />
              ),
            )
          ) : (
            <div className="card"><span className="ph"><span className="ph-empty">{e.title.charAt(0)}</span></span></div>
          )}
        </div>
        <div>
          <h1>{e.title}</h1>
          <p className="meta">{subtitleOf(e, z as ZoneDoc)}</p>
          {e.description && <p className="prose">{e.description}</p>}
          {(e.peopleTags?.length || 0) > 0 && (
            <p>{e.peopleTags!.map((t) => <span key={t} className="tag">{t}</span>)}</p>
          )}
          {e.contributor && z.type === 'memories' && <p className="meta">Gửi tặng: {e.contributor}{e.cohort ? `, ${e.cohort}` : ''}</p>}

          {tributes && (
            <section style={{ marginTop: 28 }}>
              <h2>Lời tri ân ({tributes.totalDocs})</h2>
              {tributes.docs.map((t) => (
                <blockquote key={t.id} className="quote">
                  <p className="prose">{t.message}</p>
                  <small>{t.name}{t.cohort ? `, ${t.cohort}` : ''}</small>
                </blockquote>
              ))}
              <details className="box">
                <summary className="btn ghost">Gửi lời tri ân</summary>
                <div style={{ marginTop: 14 }}>
                  <SubmitForm
                    kind="tribute"
                    hidden={{ exhibitId: String(e.id) }}
                    closed={ev.submissionsOpen === false}
                    submitLabel="Gửi lời tri ân"
                    successText="Cảm ơn bạn. Lời tri ân sẽ hiển thị sau khi nhà trường duyệt."
                    fields={[
                      { name: 'name', label: 'Họ và tên', required: true, max: 80, half: true },
                      { name: 'cohort', label: 'Khóa học hoặc lớp', max: 60, placeholder: 'VD: Khóa 1990 – 1993', half: true },
                      { name: 'message', label: 'Lời tri ân', type: 'textarea', required: true, max: 600 },
                    ]}
                  />
                </div>
              </details>
            </section>
          )}
        </div>
      </article>
      <nav className="pager" aria-label="Mục trước, mục sau">
        {prev && <Link className="chip" href={`/khu/${z.slug}/${prev.id}`}>‹ {prev.title}</Link>}
        {next && <Link className="chip" href={`/khu/${z.slug}/${next.id}`}>{next.title} ›</Link>}
      </nav>
    </div>
  )
}
