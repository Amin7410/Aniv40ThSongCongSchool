import type { Metadata } from 'next'
import { getApproved, getEvent, payload } from '@/lib/data'
import { SubmitForm } from '@/components/SubmitForm'

export const dynamic = 'force-dynamic'
export const metadata: Metadata = { title: 'Bản đồ cựu học sinh' }

type City = { id: number; code: string; name: string; country: string; lat: number; lng: number }

// Phép chiếu equirectangular cắt vùng; không vẽ đường biên giới quốc gia (tránh dữ liệu biên giới sai lệch),
// và luôn ghi chú hai quần đảo Hoàng Sa, Trường Sa của Việt Nam.
const W = 1000, H = 520
const px = (lng: number) => ((lng + 170) / 340) * W
const py = (lat: number) => ((72 - lat) / 130) * H

export default async function MapPage() {
  const [ev, pins, citiesRes] = await Promise.all([
    getEvent(),
    getApproved('pin', 1000),
    (await payload()).find({ collection: 'cities', limit: 500, sort: 'name', depth: 0 }),
  ])
  const cities = citiesRes.docs as unknown as City[]
  const byCity = new Map<number, { city: City; people: Array<{ name: string; cohort?: string | null; work?: string }> }>()
  for (const p of pins.docs) {
    const c = typeof p.city === 'object' && p.city ? (p.city as unknown as City) : cities.find((x) => x.id === p.city)
    if (!c) continue
    const e = byCity.get(c.id) || { city: c, people: [] }
    e.people.push({ name: p.name, cohort: p.cohort, work: (p.payload as { workplace?: string })?.workplace })
    byCity.set(c.id, e)
  }
  const groups = [...byCity.values()].sort((a, b) => b.people.length - a.people.length)
  return (
    <>
      <section className="zone-hero">
        <div className="wrap">
          <h1>Bản đồ cựu học sinh</h1>
          <p>{pins.totalDocs.toLocaleString('vi-VN')} cựu học sinh ở {groups.length} thành phố đã thả ghim hướng về trường.</p>
        </div>
      </section>
      <div className="wrap section">
        <figure className="map" aria-label="Bản đồ các thành phố có cựu học sinh">
          <svg viewBox={`0 0 ${W} ${H}`} role="img">
            {[-40, -20, 0, 20, 40, 60].map((lat) => <line key={lat} x1={0} x2={W} y1={py(lat)} y2={py(lat)} stroke="currentColor" opacity=".12" />)}
            {[-150, -120, -90, -60, -30, 0, 30, 60, 90, 120, 150].map((lng) => <line key={lng} y1={0} y2={H} x1={px(lng)} x2={px(lng)} stroke="currentColor" opacity=".12" />)}
            <g fontSize="11" fill="#8e1418">
              <circle cx={px(112)} cy={py(16.5)} r="2.5" /><text x={px(112) + 5} y={py(16.5) + 4}>QĐ Hoàng Sa (Việt Nam)</text>
              <circle cx={px(114)} cy={py(10)} r="2.5" /><text x={px(114) + 5} y={py(10) + 4}>QĐ Trường Sa (Việt Nam)</text>
            </g>
            {groups.map((g) => (
              <g key={g.city.id}>
                <circle cx={px(g.city.lng)} cy={py(g.city.lat)} r={Math.min(16, 4 + Math.sqrt(g.people.length) * 2)} fill="#d4ab55" stroke="#5c0a0e" strokeWidth="1.5" opacity=".9">
                  <title>{`${g.city.name}: ${g.people.length} người`}</title>
                </circle>
              </g>
            ))}
          </svg>
        </figure>
        <div className="two-col" style={{ marginTop: 20 }}>
          <section className="box">
            <h2>Theo thành phố</h2>
            <ul className="list">
              {groups.map((g) => (
                <li key={g.city.id}>
                  <b>{g.city.name}</b>, {g.city.country} — {g.people.length} người
                  <div className="meta">{g.people.slice(0, 12).map((p) => [p.name, p.cohort].filter(Boolean).join(', ')).join(' · ')}</div>
                </li>
              ))}
              {!groups.length && <li className="meta">Chưa có ghim nào được duyệt.</li>}
            </ul>
          </section>
          <section className="box">
            <h2>Thả ghim của bạn</h2>
            <SubmitForm
              kind="pin"
              closed={ev.submissionsOpen === false}
              submitLabel="Thả ghim"
              successText="Cảm ơn bạn. Ghim sẽ hiện trên bản đồ sau khi được duyệt."
              fields={[
                { name: 'name', label: 'Họ và tên', required: true, max: 80, half: true },
                { name: 'cohort', label: 'Khóa học', max: 60, half: true },
                { name: 'cityCode', label: 'Thành phố bạn đang sống', type: 'select', required: true, options: cities.map((c) => ({ value: c.code, label: `${c.name} (${c.country})` })) },
                { name: 'workplace', label: 'Nơi làm việc, lĩnh vực (không bắt buộc)', max: 100 },
              ]}
            />
          </section>
        </div>
      </div>
    </>
  )
}
