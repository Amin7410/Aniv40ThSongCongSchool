import Link from 'next/link'
import { getEvent, getMilestones, getSite, getZones, imgUrl, payload, type ExhibitDoc, type MediaDoc } from '@/lib/data'
import { Lotus } from '@/components/Lotus'
import { Countdown } from '@/components/Event'
import { MemoryBox } from '@/components/MemoryBox'
import { liveState } from '@/lib/live'

export const dynamic = 'force-dynamic'

function fmtDate(d?: string | null) {
  if (!d) return ''
  return new Date(d).toLocaleDateString('vi-VN', { timeZone: 'Asia/Ho_Chi_Minh', day: '2-digit', month: '2-digit', year: 'numeric' })
}

export default async function Home() {
  const [s, ev, zones, ms] = await Promise.all([getSite(), getEvent(), getZones(), getMilestones()])
  const founded = s.foundedDate ? new Date(s.foundedDate).getFullYear() : 1986
  const years = new Date().getFullYear() - founded
  const memZone = zones.find((z) => z.type === 'memories')
  const mem = memZone
    ? ((await (await payload()).find({ collection: 'exhibits', where: { zone: { equals: memZone.id } }, limit: 3, sort: '-createdAt', depth: 1, overrideAccess: false })).docs as unknown as ExhibitDoc[])
    : []
  const scan = s.decisionScan && typeof s.decisionScan === 'object' ? (s.decisionScan as MediaDoc) : null
  const state = liveState(ev)

  return (
    <>
      <section className="hall" aria-label="Gian trung tâm">
        <div className="wrap">
          <div className="banner">
            <Lotus />
            <h1>{s.bannerText || `${s.schoolName} – ${years} năm xây dựng và trưởng thành`}</h1>
            <Lotus />
          </div>
          <div className="hall-grid">
            <div className="panel">
              <h2>Quyết định thành lập trường</h2>
              <div className="paper">
                <span className="q">CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM</span>
                <em>Độc lập – Tự do – Hạnh phúc</em>
                <p style={{ margin: '10px 0 0' }}>
                  {s.decisionNo ? <>Quyết định số <b>{s.decisionNo}</b></> : 'Quyết định thành lập'}
                  {s.decisionIssuer ? <> của {s.decisionIssuer}</> : null}, ngày {fmtDate(s.foundedDate)}
                </p>
                {scan && imgUrl(scan, 'full') && <img src={imgUrl(scan, 'full')!} alt={scan.alt || 'Bản scan Quyết định thành lập'} />}
              </div>
            </div>
            <div className="panel">
              <h2>Hình thành và phát triển</h2>
              {ms.length ? (
                <ul className="hist">
                  {ms.map((m) => (
                    <li key={m.id}><b>{m.date}</b><span>{m.text}</span></li>
                  ))}
                </ul>
              ) : (
                <p>Nhà trường đang cập nhật các mốc lịch sử.</p>
              )}
            </div>
          </div>
        </div>
      </section>

      {state === 'before' && <Countdown startsAt={ev.startsAt} title={`${ev.title || 'Lễ kỷ niệm 40 năm'} — còn`} />}
      {state === 'live' && (
        <section className="cd"><div className="wrap"><h2>Đại lễ đang diễn ra</h2><Link className="btn" href="/dai-le">Xem trực tiếp</Link></div></section>
      )}

      <section className="section">
        <div className="wrap">
          <h2>Các khu trưng bày</h2>
          <p className="lead">Chọn một khu để xem chân dung, hiện vật và hình ảnh qua {years} năm.</p>
          <div className="grid">
            {zones.map((z) => (
              <Link key={z.id} className="card" href={`/khu/${z.slug}`}>
                <span className="cab"><b>{z.title}</b><small>{z.description?.slice(0, 90)}</small></span>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <section className="section">
        <div className="wrap">
          <h2>Hộp ký ức ngẫu nhiên</h2>
          <p className="lead">Mỗi lần bốc là một tấm ảnh tư liệu kèm câu chuyện học trò. Chọn thế hệ của bạn rồi tìm lại những khoảnh khắc thanh xuân.</p>
          <MemoryBox />
        </div>
      </section>

      <section className="section">
        <div className="wrap two-col">
          <div className="box">
            <h2>Gửi kỷ vật – Hiến tư liệu</h2>
            <p>Ảnh cũ, lưu bút, báo tường, giấy khen, đồng phục… Mỗi kỷ vật bạn gửi sẽ được nhà trường duyệt và xếp vào Góc ký ức theo thế hệ.</p>
            <Link className="btn" href="/gui-ky-vat">Gửi kỷ vật</Link>
          </div>
          <div className="box">
            <h2>Hướng về Đại lễ</h2>
            <p>Gửi lời chúc, thắp nến tri ân thầy cô và chung tay xây dựng Quỹ học bổng 40 năm.</p>
            <Link className="btn" href="/dai-le">Đến trang Đại lễ</Link>
          </div>
        </div>
      </section>

      {mem.length > 0 && memZone && (
        <section className="section">
          <div className="wrap">
            <h2>Mới trong Góc ký ức</h2>
            <div className="grid wide">
              {mem.map((e) => {
                const m = (e.media || []).find((x) => typeof x === 'object') as MediaDoc | undefined
                return (
                  <Link key={e.id} className="card land" href={`/khu/${memZone.slug}/${e.id}`}>
                    <span className="ph">{imgUrl(m) ? <img src={imgUrl(m)!} alt="" loading="lazy" className="old" /> : <span className="ph-empty">✦</span>}</span>
                    <span className="body"><b>{e.title}</b><small>{[e.contributor, e.cohort].filter(Boolean).join(', ')}</small></span>
                  </Link>
                )
              })}
            </div>
          </div>
        </section>
      )}
    </>
  )
}
