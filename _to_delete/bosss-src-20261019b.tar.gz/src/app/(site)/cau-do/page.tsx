import type { Metadata } from 'next'
import { payload } from '@/lib/data'
import { Quiz } from '@/components/Quiz'

export const dynamic = 'force-dynamic'
export const metadata: Metadata = { title: 'Câu đố 40 năm' }

export default async function QuizPage() {
  const r = await (await payload()).find({ collection: 'quiz-questions', limit: 50, sort: 'order', depth: 0 })
  const qs = r.docs.map((q) => ({ q: q.question, a: q.options || [], c: q.correctIndex, e: q.explanation || '' }))
  return (
    <div className="wrap section">
      <h1>Câu đố 40 năm</h1>
      {qs.length ? <Quiz qs={qs} /> : <p className="notice">Câu đố đang được chuẩn bị.</p>}
    </div>
  )
}
