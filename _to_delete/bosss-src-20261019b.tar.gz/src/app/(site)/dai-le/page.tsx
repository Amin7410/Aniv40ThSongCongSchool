import type { Metadata } from 'next'
import { getApproved, getEvent, getFund } from '@/lib/data'
import { embedURL, liveState } from '@/lib/live'
import { CandleBox, Countdown, FundBox, LivePanel } from '@/components/Event'
import { SubmitForm } from '@/components/SubmitForm'

export const dynamic = 'force-dynamic'
export const metadata: Metadata = { title: 'Đại lễ 40 năm (1986 – 2026)' }

export default async function EventPage() {
  const [ev, fund, gb] = await Promise.all([getEvent(), getFund(), getApproved('guestbook', 30)])
  const st = liveState(ev)
  const closed = ev.submissionsOpen === false
  const evLite = { startsAt: ev.startsAt, liveMode: ev.liveMode, liveHours: ev.liveHours }
  return (
    <>
      <section className="zone-hero">
        <div className="wrap">
          <h1>Đại lễ 40 năm (1986 – 2026)</h1>
          <p>Cùng hướng về {String(ev.title || 'lễ kỷ niệm').toLowerCase()}{ev.place ? ` tại ${ev.place}` : ''}: gửi lời chúc, thắp nến tri ân và chung tay xây dựng {fund.name}.</p>
        </div>
      </section>
      {st === 'before' && <Countdown startsAt={ev.startsAt} title="Còn" />}
      <div className="wrap section">
        <div className="box">
          <h2>Xem trực tiếp</h2>
          {ev.staticFallback ? (
            <p className="notice">Trang đang ở chế độ giảm tải. {ev.liveUrl && <a href={ev.liveUrl} target="_blank" rel="noopener noreferrer">Mở luồng phát trực tiếp</a>}</p>
          ) : (
            <LivePanel ev={evLite} embed={embedURL(ev.liveUrl)} liveUrl={ev.liveUrl} />
          )}
        </div>
      </div>
      <div className="wrap two-col">
        <section className="box" aria-labelledby="gb">
          <h2 id="gb">Sổ lưu niệm</h2>
          <p className="lead">Lời chúc được nhà trường duyệt trước khi hiển thị.</p>
          <SubmitForm
            kind="guestbook"
            closed={closed}
            submitLabel="Gửi lời chúc"
            successText="Đã gửi lời chúc. Lời chúc sẽ hiển thị sau khi được duyệt."
            fields={[
              { name: 'name', label: 'Họ và tên', required: true, max: 80, half: true },
              { name: 'cohort', label: 'Khóa học, đơn vị', max: 60, placeholder: 'VD: Khóa 2005 – 2008', half: true },
              { name: 'message', label: 'Lời chúc', type: 'textarea', required: true, max: 600 },
            ]}
          />
          <ul className="list" style={{ marginTop: 18 }}>
            {gb.docs.map((g) => (
              <li key={g.id}>
                <p className="prose" style={{ margin: 0 }}>{g.message}</p>
                <small className="meta">{g.name}{g.cohort ? `, ${g.cohort}` : ''} · {new Date(g.createdAt).toLocaleDateString('vi-VN')}</small>
              </li>
            ))}
            {!gb.docs.length && <li className="meta">Chưa có lời chúc nào được đăng.</li>}
          </ul>
        </section>
        <div className="form" style={{ gap: 18 }}>
          <section className="box" aria-labelledby="cn">
            <h2 id="cn">Thắp nến tri ân</h2>
            <p className="lead">Mỗi người thắp một ngọn nến tri ân các thế hệ thầy cô.</p>
            {ev.staticFallback ? <p className="notice">Tạm dừng trong chế độ giảm tải.</p> : <CandleBox />}
          </section>
          <section className="box" aria-labelledby="fund">
            <h2 id="fund">{fund.name}</h2>
            <FundBox />
            <details style={{ marginTop: 14 }}>
              <summary className="btn ghost">Tôi đã chuyển khoản — báo đóng góp</summary>
              <div style={{ marginTop: 14 }}>
                <SubmitForm
                  kind="donation"
                  closed={closed}
                  submitLabel="Gửi thông tin đóng góp"
                  successText="Đã nhận thông tin. Kế toán nhà trường sẽ xác nhận sau khi đối chiếu sao kê."
                  fields={[
                    { name: 'name', label: 'Họ tên hoặc tập thể', max: 80, half: true },
                    { name: 'cohort', label: 'Khóa, lớp', max: 60, half: true },
                    { name: 'amount', label: 'Số tiền (đồng)', type: 'number', required: true, half: true },
                    { name: 'contact', label: 'SĐT/Email để xác nhận (không công khai)', max: 120, half: true },
                    { name: 'message', label: 'Ghi chú (giờ chuyển, ngân hàng…)', max: 200 },
                    { name: 'anonymous', label: 'Không công khai tên tôi', type: 'checkbox' },
                  ]}
                />
              </div>
            </details>
          </section>
        </div>
      </div>
    </>
  )
}
