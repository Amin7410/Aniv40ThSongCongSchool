'use client'
import Link from 'next/link'
import { usePathname } from 'next/navigation'

export function ZoneTabs({ zones }: { zones: Array<{ slug: string; short: string }> }) {
  const path = usePathname()
  const items = [{ href: '/', label: 'Gian trung tâm' }, ...zones.map((z) => ({ href: `/khu/${z.slug}`, label: z.short })), { href: '/dai-le', label: 'Đại lễ' }]
  return (
    <nav className="tabs" aria-label="Các khu trưng bày">
      {items.map((i) => {
        const cur = i.href === '/' ? path === '/' : path.startsWith(i.href)
        return (
          <Link key={i.href} href={i.href} aria-current={cur ? 'page' : undefined}>
            {i.label}
          </Link>
        )
      })}
    </nav>
  )
}
