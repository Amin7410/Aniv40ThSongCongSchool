import type { CollectionConfig } from 'payload'
import { ROLES, admins, isAdminRole, roleOf } from '../access/roles'
import { auditAfterChange, auditAfterDelete } from '../hooks/audit'

export const Users: CollectionConfig = {
  slug: 'users',
  labels: { singular: 'Tài khoản', plural: 'Tài khoản quản trị' },
  admin: { useAsTitle: 'email', defaultColumns: ['email', 'name', 'role', 'zones'], group: 'Hệ thống' },
  auth: {
    maxLoginAttempts: 5,
    lockTime: 15 * 60 * 1000,
    tokenExpiration: 8 * 60 * 60,
    cookies: { sameSite: 'Strict', secure: process.env.NODE_ENV === 'production' },
  },
  access: {
    read: ({ req }) => (isAdminRole(roleOf(req)) ? true : req.user ? { id: { equals: req.user.id } } : false),
    create: admins,
    update: ({ req }) => (isAdminRole(roleOf(req)) ? true : req.user ? { id: { equals: req.user.id } } : false),
    delete: admins,
    admin: ({ req }) => !!req.user,
  },
  hooks: {
    beforeChange: [
      ({ req, data, originalDoc }) => {
        // Chỉ Super Admin được cấp hoặc gỡ vai trò super; người dùng thường không tự đổi vai trò.
        const actor = roleOf(req)
        if (!req.user) return data // seed/CLI
        if (data.role && data.role !== originalDoc?.role) {
          if (!isAdminRole(actor)) throw new Error('Bạn không được đổi vai trò.')
          if ((data.role === 'super' || originalDoc?.role === 'super') && actor !== 'super')
            throw new Error('Chỉ Super Admin được cấp vai trò Super Admin.')
        }
        if (!isAdminRole(actor) && data.zones && JSON.stringify(data.zones) !== JSON.stringify(originalDoc?.zones))
          throw new Error('Bạn không được tự đổi khu phụ trách.')
        return data
      },
    ],
    afterChange: [auditAfterChange],
    afterDelete: [auditAfterDelete],
  },
  fields: [
    { name: 'name', label: 'Họ và tên', type: 'text', required: true },
    {
      name: 'role',
      label: 'Vai trò',
      type: 'select',
      required: true,
      defaultValue: 'editor',
      options: ROLES.map((r) => ({ label: r.label, value: r.value })),
      saveToJWT: true,
    },
    {
      name: 'zones',
      label: 'Khu phụ trách',
      type: 'relationship',
      relationTo: 'zones',
      hasMany: true,
      saveToJWT: true,
      admin: { condition: (d) => d?.role === 'editor', description: 'Biên tập viên chỉ sửa được mục trong các khu này.' },
    },
  ],
}
