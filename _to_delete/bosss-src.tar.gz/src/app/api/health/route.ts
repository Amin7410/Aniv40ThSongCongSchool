import { getPayload } from 'payload'
import config from '@payload-config'
import { redis } from '@/lib/redis'

export const dynamic = 'force-dynamic'

export async function GET() {
  const checks: Record<string, string> = {}
  try {
    const p = await getPayload({ config })
    await p.count({ collection: 'zones', overrideAccess: true })
    checks.db = 'ok'
  } catch {
    checks.db = 'fail'
  }
  checks.redis = process.env.REDIS_URL ? (redis() ? 'ok' : 'degraded') : 'disabled'
  const ok = checks.db === 'ok'
  return Response.json({ ok, checks }, { status: ok ? 200 : 503, headers: { 'cache-control': 'no-store' } })
}
