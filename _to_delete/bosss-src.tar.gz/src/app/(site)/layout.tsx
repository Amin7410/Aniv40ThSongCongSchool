import type { Metadata, Viewport } from 'next'
import Link from 'next/link'
import './site.css'
import { getSite, getZones } from '@/lib/data'
import { Lotus } from '@/components/Lotus'
import { ZoneTabs } from '@/components/ZoneTabs'
import { SizeToggle } from '@/components/SizeToggle'

// Font tự host từ gói @fontsource (chỉ tập con tiếng Việt + Latin) — không gọi Google Fonts.
import '@fontsource/be-vietnam-pro/vietnamese-400.css'
import '@fontsource/be-vietnam-pro/vietnamese-600.css'
import '@fontsource/be-vietnam-pro/latin-400.css'
import '@fontsource/be-vietnam-pro/latin-600.css'
import '@fontsource/cormorant-garamond/vietnamese-700.css'
import '@fontsource/cormorant-garamond/latin-700.css'

export const dynamic = 'force-dynamic'

export async function generateMetadata(): Promise<Metadata> {
  const s = await getSite()
  const title = `Phòng truyền thống trực tuyến – ${s.schoolName}`
  return {
    metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL || 'http://localhost:3000'),
    title: { default: title, template: `%s – ${s.schoolName}` },
    description: `Phòng truyền thống trực tuyến ${s.schoolName}: lãnh đạo, thầy cô, cựu học sinh, khen thưởng và Góc ký ức qua 40 năm (1986 – 2026).`,
    openGraph: { type: 'website', locale: 'vi_VN', siteName: title },
  }
}

export const viewport: Viewport = { width: 'device-width', initialScale: 1, themeColor: '#5c0a0e' }

export default async function SiteLayout({ children }: { children: React.ReactNode }) {
  const [s, zones] = await Promise.all([getSite(), getZones()])
  return (
    <html lang="vi">
      <body>
        <a className="skip" href="#main">Bỏ qua thanh điều hướng</a>
        <header className="top">
          <div className="wrap top-row">
            <Link className="brand" href="/" aria-label="Về gian trung tâm">
              <Lotus />
              <span>
                <b>{s.schoolName}</b>
                <small>Phòng truyền thống trực tuyến, 1986 – 2026</small>
              </span>
            </Link>
            <SizeToggle />
            <Link className="tlink hl" href="/dai-le">Đại lễ 40 năm</Link>
          </div>
          <div className="wrap">
            <ZoneTabs zones={zones.map((z) => ({ slug: z.slug, short: z.shortTitle }))} />
          </div>
        </header>
        <main id="main">{children}</main>
        <footer className="foot">
          <div className="wrap">
            <nav aria-label="Chân trang">
              <Link href="/gui-ky-vat">Gửi kỷ vật</Link>
              <Link href="/ban-do">Bản đồ cựu học sinh</Link>
              <Link href="/cau-do">Câu đố 40 năm</Link>
              <Link href="/trang/chinh-sach-rieng-tu">Chính sách quyền riêng tư</Link>
              <Link href="/trang/dieu-khoan">Điều khoản gửi nội dung</Link>
              <Link href="/trang/lien-he">Liên hệ, yêu cầu gỡ nội dung</Link>
            </nav>
            <p>© {new Date().getFullYear()} {s.schoolName}. Tư liệu thuộc quyền sở hữu của nhà trường và người đóng góp.</p>
          </div>
        </footer>
      </body>
    </html>
  )
}
