import * as migration_20261018_161052_initial from './20261018_161052_initial';

export const migrations = [
  {
    up: migration_20261018_161052_initial.up,
    down: migration_20261018_161052_initial.down,
    name: '20261018_161052_initial'
  },
];
