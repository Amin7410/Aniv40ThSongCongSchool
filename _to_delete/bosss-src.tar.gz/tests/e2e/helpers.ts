import { createHash } from 'crypto'
import type { APIRequestContext } from '@playwright/test'

export const ADMIN = { email: process.env.E2E_ADMIN_EMAIL || 'admin@thd.local', password: process.env.E2E_ADMIN_PASSWORD || 'Admin-Password-2026!' }

/** Giải PoW phía Node (giống trình duyệt) để gọi API gửi nội dung. */
export async function pow(req: APIRequestContext): Promise<string> {
  const c = await (await req.get('/api/public/pow')).json()
  for (let n = 0; n <= c.max; n++) {
    if (createHash('sha256').update(c.salt + n).digest('hex') === c.challenge) return JSON.stringify({ ...c, number: n })
  }
  throw new Error('pow unsolved')
}

export async function submit(req: APIRequestContext, fields: Record<string, string>, opts: { ip?: string; files?: Array<{ name: string; mimeType: string; buffer: Buffer }> } = {}) {
  const multipart: Record<string, string | { name: string; mimeType: string; buffer: Buffer }> = { consent: 'true', ...fields, pow: await pow(req) }
  // Playwright multipart chỉ nhận một tệp cho mỗi khóa — đủ cho kiểm thử
  if (opts.files?.[0]) multipart.files = opts.files[0]
  return req.post('/api/public/submissions', { multipart, headers: { 'x-real-ip': opts.ip || randomIp() } })
}

export const randomIp = () => `10.${(Math.random() * 255) | 0}.${(Math.random() * 255) | 0}.${(Math.random() * 255) | 0}`

export async function login(req: APIRequestContext, email = ADMIN.email, password = ADMIN.password): Promise<string> {
  const r = await req.post('/api/users/login', { data: { email, password } })
  if (!r.ok()) throw new Error(`login failed ${r.status()} ${await r.text()}`)
  return (await r.json()).token
}

export const auth = (token: string) => ({ Authorization: `JWT ${token}` })
