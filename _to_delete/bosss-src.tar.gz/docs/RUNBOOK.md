# Runbook vận hành

## 1. Dựng máy chủ lần đầu (staging hoặc production)

1. Ubuntu 24.04 LTS, 4 vCPU / 8 GB (production ngày thường). Tạo user `deploy`, chỉ cho SSH bằng khóa, tắt đăng nhập root, cài `fail2ban`, `unattended-upgrades`.
2. Tường lửa: `ufw allow 80,443/tcp`; SSH và cổng quản trị chỉ mở qua WireGuard.
3. Cài Docker Engine + compose plugin. Đăng nhập GHCR bằng token chỉ đọc gói (`read:packages`).
4. `git clone` repo vào `/opt/bosss`, tạo `/opt/bosss/.env` từ `.env.example` (quyền 600):
   - `PAYLOAD_SECRET`, `HASH_SECRET`: `openssl rand -base64 48`
   - `POSTGRES_PASSWORD`, và `DATABASE_URL=postgres://bosss:<mật khẩu>@postgres:5432/bosss`
   - `NEXT_PUBLIC_SITE_URL=https://<tên miền>`
   - `BACKUP_AGE_RECIPIENT=<khóa công khai age>` (khóa bí mật giữ ngoại tuyến)
5. Sửa tên miền trong `infra/nginx/site.conf`, lấy chứng chỉ: `certbot certonly --webroot -w /var/www/certbot -d <tên miền>` (chạy Nginx tạm cổng 80 lần đầu).
6. Bật danh sách IP được vào `/admin` trong `site.conf` (`allow`/`deny`).
7. `docker compose -f infra/docker-compose.prod.yml --env-file .env up -d postgres redis`
8. `docker compose -f infra/docker-compose.prod.yml --env-file .env run --rm migrate`
9. Tạo Super Admin: `docker compose ... run --rm -e SEED_ADMIN_EMAIL=... -e SEED_ADMIN_PASSWORD=... migrate pnpm seed` (**không** thêm `--demo`).
10. `docker compose ... up -d` rồi kiểm tra `https://<tên miền>/api/health`.

## 2. Triển khai bản mới

GitHub → Actions → **Deploy** → chọn môi trường. Workflow kéo image theo SHA, chạy migration, thay `web1` rồi `web2`, kiểm tra health. **Rollback:** chạy lại Deploy với SHA trước đó (migration phải tương thích ngược).

Đóng băng: từ 16/11 18:00 đến 21/11 chỉ deploy bản sửa lỗi nghiêm trọng.

## 3. Sao lưu và khôi phục

- Service `backup` dump Postgres mỗi giờ (giữ 48 bản), nén media lúc 02:00 (giữ 30 bản), mã hóa bằng `age`.
- Đồng bộ thư mục volume `backups` ra kho S3 của nhà cung cấp khác vùng (cron trên host, ví dụ `rclone sync`).
- Khôi phục (diễn tập 13/11 trên staging):
  ```bash
  age -d -i key.txt bosss-XXXX.dump.age > db.dump
  docker compose ... exec -T postgres pg_restore -U bosss -d bosss --clean --if-exists < db.dump
  ```

## 4. Công tắc khẩn cấp

| Tình huống | Thao tác |
|---|---|
| Spam hoặc tấn công qua form | Admin → Cấu hình → Đại lễ & công tắc khẩn → bỏ tích "Cho phép khách gửi nội dung" |
| Ứng dụng quá tải | Bật "Chế độ tĩnh" (ẩn phần động) |
| Ứng dụng sập hoặc quá tải nặng | Trên host: `touch infra/nginx/static-fallback/ON` → mọi trang trả về trang tĩnh (link YouTube). Gỡ bằng `rm` |
| Cảnh báo đổi tài khoản quỹ | Khóa tài khoản người đổi, khôi phục giá trị theo Nhật ký thao tác, báo Ban Giám hiệu |

**Trước 19/11:** cập nhật link YouTube trong `infra/nginx/static-fallback/index.html`.

## 5. Kiểm thử tải (S4)

```bash
k6 run -e BASE=https://staging.<tên miền> tests/load/event-day.js
```

Kiểm tra 5.000 kết nối SSE bằng một script Node mở kết nối tới `/api/public/live/stream`, kèm 200 POST/giây vào `/api/public/reactions`.
Trên staging có thể đặt `POW_DISABLED=1` (chỉ có tác dụng khi `NODE_ENV` khác `production`) để đo tải form.

## 6. Lưu ý bảo mật vận hành

- Ứng dụng tin header `X-Real-IP` để giới hạn tần suất. **Chỉ Nginx được mở cổng ra ngoài**; không publish cổng 3000 của `web*`.
- Hai biến `PAYLOAD_SECRET` và `HASH_SECRET` không được đổi tùy tiện: đổi `PAYLOAD_SECRET` sẽ đăng xuất mọi người; đổi `HASH_SECRET` làm mất liên kết chống trùng và token xem trạng thái của người gửi.
