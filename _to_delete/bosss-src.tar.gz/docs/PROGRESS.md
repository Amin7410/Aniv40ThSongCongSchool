# Tiến độ triển khai so với thiết kế

Cập nhật: 18/10/2026 (Sprint 1, ngày 0). Trạng thái: ✅ xong và có kiểm thử · 🟡 làm một phần · ⬜ chưa làm.

## Đã kiểm chứng

- `pnpm lint`, `pnpm typecheck`: sạch.
- Unit test: 18/18 đạt.
- E2E Playwright: 26/26 đạt (21 desktop + 5 UI trên Pixel 7), chạy trên bản build production, Postgres 16, Redis 7.
- Migration khởi tạo chạy được trên CSDL trống (`NODE_ENV=production pnpm migrate`).
- SSE: 800 kết nối đồng thời trên 1 tiến trình, cả 800 nhận gói cảm xúc gộp và số người xem đúng.
- Nginx: cấu hình hợp lệ; micro-cache HIT; header bảo mật có ở mọi location; trang dự phòng tĩnh bật/tắt bằng tệp `ON`; SSE không bị đệm.

## Chức năng (mục 3 thiết kế)

| ID | Trạng thái | Ghi chú |
|---|---|---|
| F-01 Gian trung tâm | ✅ | Ảnh scan Quyết định, dòng thời gian từ CMS |
| F-02 8 khu, lọc, tìm không dấu | ✅ | E2E-01, E2E-02. Tìm kiếm lọc ở ứng dụng; chuyển `unaccent`/`pg_trgm` khi > vài nghìn mục |
| F-03 Ngày ấy – Bây giờ | 🟡 | Có trường `pairKey`; chưa có thanh trượt |
| F-04 Khen thưởng | ✅ | Biểu tượng theo loại hiện vật khi chưa có ảnh |
| F-05 Góc ký ức theo thế hệ | ✅ | Tự gán thế hệ theo năm/khóa |
| F-06 Hộp ký ức ngẫu nhiên | ⬜ | S2 |
| F-07 Gửi kỷ vật/ảnh | ✅ | E2E-04: xóa EXIF/GPS, tệp chờ duyệt không công khai, duyệt → tạo mục trưng bày |
| F-08 Sổ lưu niệm | ✅ | E2E-03, E2E-05 (XSS) |
| F-09 Lời tri ân bằng chữ | ✅ | Trên thẻ Lãnh đạo, CBGV |
| F-10 Thắp nến | ✅ | E2E-13 |
| F-11 Bản đồ (duyệt trước) | ✅ | E2E-14. Bản đồ chấm điểm, không vẽ biên giới, ghi chú QĐ Hoàng Sa, Trường Sa (Việt Nam) |
| F-12 Quỹ + VietQR | ✅ | E2E-09, E2E-10; CRC VietQR kiểm bằng vector chuẩn |
| F-13 Đếm ngược, trạng thái phát | ✅ | Unit test `liveState` |
| F-14 Nhúng livestream | ✅ | Chỉ YouTube (nocookie) / Facebook, kiểm hostname |
| F-15 Cảm xúc + người xem (SSE) | ✅ | Gộp theo giây qua Redis pub/sub; quá tải → `busy` |
| F-16 Câu đố | ✅ | |
| F-17 Kỷ yếu lật trang | ⬜ | S3 |
| F-18 Nhạc nền | ⬜ | Có trường cấu hình; chưa có trình phát |
| F-19 Chia sẻ, OG | 🟡 | Metadata/OG cơ bản; chưa có ảnh OG tự sinh |
| F-20 Chữ lớn | ✅ | |
| F-21 Chính sách, điều khoản, liên hệ | 🟡 | Văn bản mẫu — **pháp chế và nhà trường phải rà soát** |
| A-01 Đăng nhập, khóa sau 5 lần sai | 🟡 | Có khóa tài khoản, cookie Strict. **2FA TOTP chưa làm (S2, bắt buộc trước go-live)** |
| A-02 CRUD 8 khu, nháp/xuất bản | ✅ | |
| A-03 Thư viện media | ✅ | Nén WebP, 3 kích thước, bỏ metadata |
| A-04/A-05 Hàng chờ kiểm duyệt, đưa vào khu | 🟡 | Dùng list/edit của Payload + trường "Khu đích". Chưa có view tùy biến + phím tắt + thao tác hàng loạt |
| A-06 Cấu hình Đại lễ | ✅ | |
| A-07 Quỹ 2 người duyệt | ✅ | Ghi nhật ký + log cảnh báo. **Chưa gửi email** (cần SMTP) |
| A-08 Người dùng, vai trò, khu | ✅ | E2E-08 (kể cả tự nâng quyền) |
| A-09 Nhật ký thao tác | ✅ | Chỉ ghi thêm ở tầng ứng dụng. S2: thu hồi quyền UPDATE/DELETE ở tầng Postgres |
| A-10 Bảng tổng quan | ⬜ | S3 |
| A-11 Xuất CSV | ⬜ | S3 |
| A-12 Công tắc khẩn | ✅ | `submissionsOpen` (E2E-18), `staticFallback`, trang tĩnh Nginx |

## Khác với thiết kế (cần ghi nhận)

| Thiết kế | Thực tế | Lý do |
|---|---|---|
| Next.js 15 | **Next.js 16.4** | Payload 3.91 hỗ trợ Next 15.4.x hoặc 16.3+; chọn bản 16 ổn định mới nhất |
| Thư viện ALTCHA | **PoW tự viết cùng cơ chế** (`src/lib/pow.ts`, khoảng 60 dòng) | API altcha-lib v2 mới đổi; tự viết dễ kiểm soát, không thêm phụ thuộc. Mỗi lời giải chỉ dùng 1 lần (Redis NX) |
| Media trên S3 | **Volume cục bộ** (`/data/media`, `/data/quarantine`) | Chưa chốt nhà cung cấp (D2). Thêm `@payloadcms/storage-s3` khi có thông tin |
| Worker BullMQ | **Chưa cần** | Xử lý ảnh nhanh, chạy ngay trong request. Sẽ thêm khi làm kỷ yếu PDF và email |
| CSP dùng nonce | CSP có `'unsafe-inline'` cho script | S2: middleware sinh nonce |
| Font tự host | Gói `@fontsource` (tập con tiếng Việt) | Không gọi Google Fonts lúc chạy lẫn lúc build |

## Việc tiếp theo (Sprint 1 còn lại → S2)

1. **2FA TOTP** cho tài khoản quản trị (bắt buộc).
2. Email giao dịch (SMTP): cảnh báo đổi tài khoản quỹ, quên mật khẩu.
3. View kiểm duyệt tùy biến: phím tắt, thao tác hàng loạt, ảnh xem trước.
4. CSP nonce; thu hồi UPDATE/DELETE trên `audit_logs` ở Postgres.
5. Storage S3 khi chốt nhà cung cấp; job đồng bộ sao lưu ra ngoài.
6. Hộp ký ức ngẫu nhiên, thanh trượt Ngày ấy – Bây giờ, kỷ yếu, nhạc nền.
7. Staging VPS + domain tạm; chạy workflow Deploy lần đầu.
